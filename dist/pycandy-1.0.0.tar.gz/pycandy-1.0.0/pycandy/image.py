import pygame

def display_image(image_path):
    image_path = ""
    image = pygame.image.load(image_path)